export type ExamStatus = 'healthy' | 'warning' | 'danger';

export interface ExamResult {
  id: string;
  examId?: string;
  name: string;
  value: number;
  unit: string;
  referenceMin: number;
  referenceMax: number;
  status: ExamStatus;
  date: string;
  category: string;
  fileUrl?: string | null;
  fileName?: string | null;
}

export interface ExamHistory {
  examName: string;
  unit: string;
  referenceMin: number;
  referenceMax: number;
  history: {
    date: string;
    value: number;
    status: ExamStatus;
  }[];
}

export interface HealthSummary {
  totalExams: number;
  healthy: number;
  warning: number;
  danger: number;
  lastUpdate: string;
}
